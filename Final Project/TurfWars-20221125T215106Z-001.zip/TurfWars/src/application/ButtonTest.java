package application;
import javafx.scene.control.Button;

public class ButtonTest extends Button{

	private String name;
	
	public void setName(String n)
	{
		name = n;
	}
	public String getname() {
		return name;
	}
	
  
    
}
