package application;

public class AI {

}
