package application;

public class PlayerSuper {

}
