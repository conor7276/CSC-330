package application;

public class User {

}
