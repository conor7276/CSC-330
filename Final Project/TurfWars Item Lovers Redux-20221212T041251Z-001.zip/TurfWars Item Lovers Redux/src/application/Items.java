package application;
import javafx.scene.image.ImageView;
public interface Items {

	public GridSquare[][] Use(GridSquare[][] gameboard, String SlimeTrail_String, int[] location, PlayerSuper slime);
	
}
