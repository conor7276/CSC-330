package application;

import java.util.Scanner;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class User extends PlayerSuper{
	GridSquare temp;
	@Override
	public GridSquare[][] Movement(GridSquare[][] updated_state, String direction) {
		if(direction == "west") {
		if (this.GetWest() == null || this.GetWest().getURL() == "Assets/Purple_Slime_Icon.png" || this.GetWest().getURL() == "Assets/Blue_Slime_Icon.png" || this.GetWest().getURL() == "Assets/Green_SlimeTrail.png" || this.GetWest().getURL() == "Assets/Pink_Slime_Icon.png") {
			System.out.println("cannot move there");
		} else {
			
			temp = updated_state[this.getLocation()[0]][this.getLocation()[1]-1];
			
			updated_state[this.getLocation()[0]][this.getLocation()[1]-1]=this;
			
			
	this.setLocation(this.getLocation()[0],(this.getLocation()[1]-1));
	
	
//			System.out.println(this.getLocation()[0] + ", " + this.getLocation()[1]);
//			System.out.println("after line 21");
		
 		updated_state[temp.getLocation()[0]][temp.getLocation()[1]+1]=temp;
		temp.setLocation(temp.getLocation()[0], temp.getLocation()[1]+1);
		System.out.println(temp.getLocation()[1]);
		
		temp.setGraphic(getTrail());
		
		System.out.println(updated_state[0][7].getURL());
			
			temp.setCardinalConnections(updated_state);
			this.setCardinalConnections(updated_state);
			
		}
		
		}
		return updated_state;
	}

}
