package application;

public class User extends PlayerSuper{

	
	
	
	

	@Override
	public GridSquare[][] Movement(GridSquare[][] updated_state) {
		this.setGame_state(updated_state);
		
		
		
		return this.getGame_state();
	}

}
