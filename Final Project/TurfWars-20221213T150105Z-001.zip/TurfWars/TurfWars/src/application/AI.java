package application;

public class AI extends PlayerSuper {

	
	
	
	
	
	
	@Override
	public GridSquare[][] Movement(GridSquare[][] updated_state) {
		// TODO Auto-generated method stub
		return null;
	}

}
