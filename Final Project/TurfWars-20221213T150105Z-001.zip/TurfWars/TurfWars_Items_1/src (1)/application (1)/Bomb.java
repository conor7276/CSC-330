package application;

public class Bomb implements Items{

	@Override
	public GridSquare Use(GridSquare gameboard) {
		// TODO Auto-generated method stub
		return null;
	}

}
