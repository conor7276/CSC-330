package application;

public class Vertical_Beam implements Items{

	@Override
	public GridSquare Use(GridSquare gameboard) {
		// TODO Auto-generated method stub
		return null;
	}

}
