package application;

public class Horizontal_Beam implements Items{

	@Override
	public GridSquare Use(GridSquare gameboard) {
		// TODO Auto-generated method stub
		return null;
	}

}
