package application;

public interface Items {

	public GridSquare Use(GridSquare gameboard);
	
}
