module Chapter12Notes {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
